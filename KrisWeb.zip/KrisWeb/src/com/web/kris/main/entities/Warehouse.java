package com.web.kris.main.entities;

/**
 * Created by Mohru on 2016-01-26.
 */
public class Warehouse {
}
