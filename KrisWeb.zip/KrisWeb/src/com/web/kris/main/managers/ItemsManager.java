package com.web.kris.main.managers;

import com.web.kris.main.entities.Item;

/**
 * Created by Mohru on 2016-01-26.
 */
public class ItemsManager {

    public String saveItem(Item item){    //  save & update
        return "";
    }

    public Item getItem(String itemId){
        return null;
    }

    public boolean deleteItem(String itemId){
        return true;
    }
}
