package com.web.kris.main.managers;

import com.web.kris.main.entities.Warehouse;

/**
 * Created by Mohru on 2016-01-26.
 */
public class WarehousesManager {

    public String saveWarehouse(Warehouse warehouse){    //  save & update
        return "";
    }

    public Warehouse getWarehouse(String warehouseId){
        return null;
    }

    public boolean deleteWarehouse(String warehouseId){
        return true;
    }
}
