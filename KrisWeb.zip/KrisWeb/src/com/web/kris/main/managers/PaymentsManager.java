package com.web.kris.main.managers;

import com.web.kris.main.entities.Payment;

/**
 * Created by Mohru on 2016-01-26.
 */
public class PaymentsManager {

    public String savePayment(Payment payment){    //  save & update
        return "";
    }

    public Payment getPayment(String paymentId){
        return null;
    }

    public boolean deletePayment(String paymentId){
        return true;
    }
}
